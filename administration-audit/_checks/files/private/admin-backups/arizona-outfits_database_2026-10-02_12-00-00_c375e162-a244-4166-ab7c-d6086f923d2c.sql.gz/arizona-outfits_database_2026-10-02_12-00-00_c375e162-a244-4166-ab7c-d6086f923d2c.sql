-- Arizona Outfits database backup
-- Created: 2026-10-02 12:00:00
SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admin_backups`;
CREATE TABLE `admin_backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(30) NOT NULL,
  `disk` varchar(50) NOT NULL DEFAULT 'local',
  `file_path` varchar(255) NOT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `status` varchar(30) NOT NULL DEFAULT 'processing',
  `table_count` int(10) unsigned NOT NULL DEFAULT 0,
  `row_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_backups_created_by_foreign` (`created_by`),
  KEY `admin_backups_status_created_at_index` (`status`,`created_at`),
  KEY `admin_backups_type_created_at_index` (`type`,`created_at`),
  CONSTRAINT `admin_backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_backups` (`id`,`created_by`,`name`,`type`,`disk`,`file_path`,`file_size`,`status`,`table_count`,`row_count`,`error_message`,`completed_at`,`created_at`,`updated_at`,`admin_id`) VALUES ('1',NULL,'arizona-outfits_database_2026-10-02_12-00-00_6e2e4b0b-1b84-480e-834e-81ccf7e87d4f.sql.gz','database','local','admin-backups/arizona-outfits_database_2026-10-02_12-00-00_6e2e4b0b-1b84-480e-834e-81ccf7e87d4f.sql.gz','920','completed','4','3',NULL,'2026-10-02 12:00:00','2026-10-02 12:00:00','2026-10-02 12:00:00',NULL);
INSERT INTO `admin_backups` (`id`,`created_by`,`name`,`type`,`disk`,`file_path`,`file_size`,`status`,`table_count`,`row_count`,`error_message`,`completed_at`,`created_at`,`updated_at`,`admin_id`) VALUES ('2',NULL,'arizona-outfits_database_2026-10-02_12-00-00_c375e162-a244-4166-ab7c-d6086f923d2c.sql.gz','database','local','admin-backups/arizona-outfits_database_2026-10-02_12-00-00_c375e162-a244-4166-ab7c-d6086f923d2c.sql.gz','0','processing','0','0',NULL,NULL,'2026-10-02 12:00:00','2026-10-02 12:00:00',NULL);

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fixture_items`;
CREATE TABLE `fixture_items` (
  `id` int(11) NOT NULL,
  `label` text DEFAULT NULL,
  `raw_bytes` blob DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `doubled` int(11) GENERATED ALWAYS AS (`quantity` * 2) STORED,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fixture_items` (`id`,`label`,`raw_bytes`,`quantity`) VALUES ('0','Quotes \' \" \\ and Unicode سلام','\0�','3');
INSERT INTO `fixture_items` (`id`,`label`,`raw_bytes`,`quantity`) VALUES ('1',NULL,NULL,'5');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS=1;
