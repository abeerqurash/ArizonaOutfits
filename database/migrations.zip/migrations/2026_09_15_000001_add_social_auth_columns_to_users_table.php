<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table
                ->string('google_id')
                ->nullable()
                ->unique()
                ->after('email');

            $table
                ->string('facebook_id')
                ->nullable()
                ->unique()
                ->after('google_id');

            $table
                ->text('avatar')
                ->nullable()
                ->after('facebook_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropUnique(['google_id']);
            $table->dropUnique(['facebook_id']);

            $table->dropColumn([
                'google_id',
                'facebook_id',
                'avatar',
            ]);
        });
    }
};